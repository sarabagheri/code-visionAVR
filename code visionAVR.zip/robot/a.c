#include <mega16a.h>
#asm
.equ __lcd_port=0x18
#endasm
#include <lcd.h>
#include <delay.h>
#include <stdio.h>
signed char i;
unsigned char j,step[]={0x01,0x02,0x04,0x8};

void motor1(void){
   for(j=0; j<45; j++){ //step=2 ==> 360/8=45
         for(i=3; i>=0; i--){ // 4 step ==> 4*2=8 Step Angle  //Right
          PORTC=step[i];
          delay_ms(130);
         }
      } 
          /*   dande aghab
      for(j=0; j<45; j++){ //step=2 ==> 3130/8=45
         for(i=0; i<=3; i++){ // 4 step ==> 4*2=8 Step Angle  //Left
          PORTC=step[i];
          delay_ms(130);
         }
      }   */
}

void motor2(void){
  for(j=0; j<45; j++){ //step=2 ==> 3130/8=45
         for(i=3; i>=0; i--){ // 4 step ==> 4*2=8 Step Angle  //Right
          PORTD=step[i];
          delay_ms(130);
         }
      } 
       /*   dande aghab
      for(j=0; j<45; j++){ //step=2 ==> 3130/8=45
         for(i=0; i<=3; i++){ // 4 step ==> 4*2=8 Step Angle  //Left
          PORTD=step[i];
          delay_ms(130);
         }
      } */
}

void motor3(void){
      
   for(j=0; j<45; j++){ //step=2 ==> 3130/8=45
         for(i=3; i>=0; i--){ // 4 step ==> 4*2=8 Step Angle  //Right
          PORTC=step[i];
          PORTD=step[i];
          delay_ms(130);
         }
      } 
           /*   dande aghab
      for(j=0; j<45; j++){ //step=2 ==> 3130/8=45
         for(i=0; i<=3; i++){ // 4 step ==> 4*2=8 Step Angle  //Left
          PORTC=step[i];
          PORTD=step[i];
          delay_ms(130);
         }
      } */          
}

void main(void)
{
PORTA=0x00;
DDRA=0x00; //sensor
PORTC=0x00;  //motor 1
DDRC=0xff; 
PORTD=0x00;  //motor 2
DDRD=0xff; 
PORTB=0xff;  //lcd
DDRB=0xff;
 lcd_init(16); 
while (1)
      {
        
           
           if(PINA==0x07) { 
                 lcd_clear();
                 lcd_gotoxy(0,0);
                 lcd_putsf("stop");
                 PORTC=0x00;
                 PORTB=0x00;
                 break ;
           } 
             
           else if(PINA==0x00) { 
                 lcd_clear();
                 lcd_gotoxy(0,0);
                 lcd_putsf("END Line");
                 PORTC=0x00;
                 PORTB=0x00;
                 break ;
           }
           else if(PINA==0x05){
            //forward 
            lcd_clear() ;
            lcd_gotoxy(0,0);
            lcd_putsf("forward");
             motor3();
             ;
              
             }
           else if(PINA==0x03){ 
             //right();
             lcd_clear();
             lcd_gotoxy(0,0);
             lcd_putsf("right");  
             motor1();
                 
               
           }
           else if(PINA==0x06) {
            //left();
               lcd_clear();
               lcd_gotoxy(0,0);
               lcd_putsf("left"); 
               motor2();
              
             
           }
      }
}
